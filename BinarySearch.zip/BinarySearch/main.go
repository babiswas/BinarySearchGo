package main

import (
	"binarysearch/app"
	"flag"
	"fmt"
)

func main() {
	opr := flag.String("ops", "bsearch", "a string")
	flag.Parse()
	ops := *opr
	switch ops {
	case "bsearch":
		arr := []int{12, 14, 19, 26, 28, 29, 30}
		for _, val := range arr {
			index := app.Bsearch(arr, 0, len(arr)-1, val)
			fmt.Printf("The index of the key %d is: %d", val, index)
			fmt.Println("")
		}
	case "noorder":
		fmt.Println("=============================================")
		fmt.Println("Ascending order:")
		brr := []int{10, 16, 18, 29, 30, 36, 40}
		for _, val := range brr {
			index := app.BSearchNoOrder(brr, 0, len(brr)-1, val)
			fmt.Printf("The index of the key %d is: %d\n", val, index)
		}
		fmt.Println("")
		fmt.Println("==============================================")
		fmt.Println("Descending order:")
		crr := []int{40, 39, 34, 25, 24, 11, 5, 4, 3}
		for _, val := range crr {
			index := app.BSearchNoOrder(crr, 0, len(crr)-1, val)
			fmt.Printf("The index of the key %d is: %d\n", val, index)
		}
	case "firstO":
		fmt.Println("First occurance of the key.")
		drr := []int{2, 3, 5, 10, 10, 14, 16, 18}
		index := app.FirstOccurance(drr, 0, len(drr)-1, 10)
		fmt.Println("The first occurance of 10 is:", index)
	case "lastO":
		fmt.Println("The last occurance of the key is:")
		mrr := []int{2, 5, 9, 10, 10, 10, 16, 17, 19}
		index := app.LastOccurance(mrr, 0, len(mrr)-1, 10)
		fmt.Println("The last occurance of the key 10 is:", index)
	case "nearlyS":
		fmt.Println("Find key in nearly sorted array:")
		drr := []int{2, 5, 9, 11, 17, 15, 20}
		for _, val := range drr {
			index := app.NearlySorted(drr, 0, len(drr)-1, val)
			fmt.Println("The index of the key is:", index)
		}
	case "floorF":
		fmt.Println("Floor function:")
		grr := []int{2, 5, 6, 9, 15, 19, 21}
		num := float64(0)
		for idx, val := range grr {
			if idx%2 == 0 {
				num = float64(val) - float64(.3)
			} else if idx%2 != 0 {
				num = float64(val) + float64(.4)
			}
			index := app.FloorFunc(grr, 0, len(grr)-1, num)
			fmt.Println("The floor value for the key is:", grr[index])
		}
	case "ceiling":
		krr := []int{2, 5, 6, 9, 15, 19, 21}
		fmt.Println("Displaying ceiling function:")
		num := float64(0)
		for idx, val := range krr {
			if idx%2 == 0 {
				num = float64(val) - float64(.3)
			} else if idx%2 != 0 {
				num = float64(val) + float64(.4)
			}
			index := app.CeilingFunc(krr, 0, len(krr)-1, num)
			fmt.Println("The floor value for the key is:", krr[index])
		}
	case "rotated":
		trr := []int{11, 12, 15, 18, 2, 3, 5, 7}
		for _, val := range trr {
			index := app.RotatedSorted(trr, 0, len(trr)-1, val)
			fmt.Println("The index of the element in rotated array:", index)
		}
	case "minmE":
		srr := []int{11, 12, 15, 18, 2, 3, 5, 7}
		index := app.FindMinmElement(srr, 0, len(srr)-1)
		fmt.Println("The index of the minimum element is:", index)

	case "minmdiff":
		xrr := []int{4, 5, 8, 10, 15, 18, 21, 26}
		fmt.Println("The minm difference element is:")
		keys := []int{6, 7, 9, 13, 14, 17, 19, 24}
		for _, val := range keys {
			app.MinmDiff(xrr, 0, len(xrr)-1, val)
		}
	case "findE":
		err := []int{3, 5, 7, 9, 10, 90, 100, 130, 140, 160, 170}
		fmt.Println("Finding the element in an infinite array:")
		index := app.FindElementInfinite(err, 10)
		fmt.Println("The index of the element 10 is:", index)
	case "peakE":
		hrr := []int{10, 20, 15, 2, 23, 90, 80}
		fmt.Println("The peak element of the array:")
		index := app.PeakElement(hrr, 0, len(hrr)-1)
		fmt.Println("The index of the peak element:", hrr[index])
	default:
		fmt.Println("Default operations executed.")
	}
}
