package app

import "fmt"

func MinmDiff(arr []int, start, end int, key int) {
	for start <= end {
		mid := (start + (end-start)/2)
		if arr[mid] == key {
			break
		} else if arr[mid] > key {
			end = mid - 1
		} else if arr[mid] < key {
			start = mid + 1
		}
	}
	fmt.Println("The minm difference elements are:", arr[end], arr[start])
}
