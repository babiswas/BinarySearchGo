package app

func NearlySorted(arr []int, start, end, key int) int {
	for start <= end {
		mid := (start + (end-start)/2)
		if arr[mid] == key {
			return mid
		} else if arr[mid+1] == key {
			return mid + 1
		} else if arr[mid-1] == key {
			return mid - 1
		} else if (mid < len(arr)-1) && (arr[mid] < key) {
			start = mid + 1
		} else if (mid > 0) && (arr[mid] > key) {
			end = mid - 1
		}
	}
	return -1
}
