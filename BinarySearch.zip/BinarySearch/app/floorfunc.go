package app

func FloorFunc(arr []int, start, end int, key float64) int {
	result := 0
	for start <= end {
		mid := (start + (end-start)/2)
		if float64(arr[mid]) == key {
			return mid
		} else if float64(arr[mid]) > key {
			end = mid - 1
		} else if float64(arr[mid]) <= key {
			result = mid
			start = mid + 1
		}
	}
	return result
}
