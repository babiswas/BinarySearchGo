package app

func PeakElement(arr []int, start, end int) int {
	for start <= end {
		mid := (start + (end-start)/2)
		next := mid + 1%len(arr)
		prev := (mid - 1 + len(arr)) % len(arr)
		if arr[mid] > arr[mid-1] && arr[mid] > arr[next] {
			return mid
		} else if arr[mid] < arr[next] {
			start = mid + 1
		} else if arr[mid] < arr[prev] {
			end = mid - 1
		}
	}
	return -1
}
