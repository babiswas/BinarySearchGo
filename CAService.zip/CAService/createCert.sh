#!/bin/bash

DIR="Certs"
mkdir -p "$DIR"

openssl genrsa -out Certs/root.key 4096
openssl req -x509 -new -nodes -key Certs/root.key -sha256 -days 3650 -out Certs/root.crt -subj "/C=US/ST=CA/L=SanFrancisco/O=GoCA/OU=RootCA/CN=GoRootCA"