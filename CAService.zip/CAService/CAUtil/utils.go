package CAUtil

import (
	"crypto/x509"
	"errors"
)

func parsePrivateKey(der []byte) (interface{}, error) {
	key, err := x509.ParsePKCS1PrivateKey(der)
	if err == nil {
		return key, nil
	}
	parsedKey, err := x509.ParsePKCS8PrivateKey(der)
	if err == nil {
		return parsedKey, nil
	}
	return nil, errors.New("unsupported key type")
}
