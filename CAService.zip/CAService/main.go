package main

import (
	"CAService/CAUtil"
	"io"
	"net/http"
)

func main() {
	caService, err := CAUtil.LoadCA("Certs/root.crt", "Certs/root.key")
	if err != nil {
		panic(err)
	}

	http.HandleFunc("/sign", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Only POST allowed", http.StatusMethodNotAllowed)
			return
		}

		csr, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "Failed to read CSR", http.StatusBadRequest)
			return
		}

		certPEM, err := caService.SignCSR(csr)
		if err != nil {
			http.Error(w, "Failed to sign CSR: "+err.Error(), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/x-pem-file")
		w.Write(certPEM)
	})

	http.ListenAndServe(":8080", nil)
}
